const errors = {
  "genericError": " oh no there was an error please contact support  ",
  "wiiError": " oh no there was an error please contact support "
};

module.exports = errors;
